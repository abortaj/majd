<template>
	<footer>
		<span>&copy; 2017 - Blog</span>
	</footer>
</template>

<script>
    export default {
        mounted() {
        }
    }
</script>
