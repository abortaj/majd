<?php
return[
    'success' => 'تمت العملية بنجاح.'
];