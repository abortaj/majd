<?php

return[
    'title' => 'Login To Your Account',
    'email' => 'Email:',
    'password' => 'Password:',
    'login' => 'Login',
    'alternative_login' => 'OR Login With:',
    'forget_password'=>'Forget Password?',
    'no_account' => "You Don't Have Account? Register Now!"
];