<?php

return [

    // Top bar
    'admin' => 'لوحة التحكم',
    'author' => 'الكاتب',
    'profile' => 'ملف التعريف',
    'login' => 'تسجيل الدخول',
    'register' => 'حساب جديد',
    'logout' => 'تسجيل الخروج',
    'new_post' => 'منشور جديد',
    // Main bar
    'home' => 'الرئيسية',
    'news' => 'أخبار',
    'articles' => 'مقالات',
    'sites' => 'مواقع',
    'reports' => 'تقارير',
    'companies' => 'شركات',
    'pcs' => 'حواسيب',
    'programs' => 'برامج',
    'programming' => 'برمجة'
];