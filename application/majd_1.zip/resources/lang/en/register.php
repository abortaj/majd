<?php

return[
    'title' => 'Create New Account',
    'first_name' => 'First Name:',
    'last_name' => 'Last Name:',
    'email' => 'Email Address:',
    'password' => 'Password:',
    'reenter_password' => 'Re-Enter Password:',
    'register' => 'Register Now',
    'alternative_register' => 'OR Register With:',
    'you_have_account' => "You Have An Account? Login From Here!"
];