<?php

return[
    'subscribe_title' => 'اشترك في خدمة الرسائل',
    'enter_email' => 'ادخل بريدك الإلكتروني',
    'subscribe_now' => 'اشترك الأن',
    'privacy' => 'سياسة الخصوصية',
    'terms' => 'الشروط',
    'faq' => 'أسئلة شائعة',
    'copyrights' => 'المدونة التقنية © جميع الحقوق محفوظة'
];