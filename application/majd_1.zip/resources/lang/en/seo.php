<?php
return[
    'faq' => 'أسئلة متكررة',
    'privacy' => 'سياسة الخصوصية',
    'terms' => 'شروط الإستخدام',
    'login' => 'Login',
    'register' => 'حساب جديد',
    'admin' => 'الإدارة',
    'thanks' => 'شكراً',
];