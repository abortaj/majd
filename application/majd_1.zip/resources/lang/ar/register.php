<?php

return[
    'title' => 'قم بإنشاء حسابك الأن.',
    'name' => 'الاسم',
    'email' => 'البريد الإلكتروني',
    'password' => 'كلمة المرور',
    'password_confirmation' => 'تأكيد كلمة المرور',
    'register' => 'إنشاء الحساب',
    'already_registered' => 'هل تملك حساب بالفعل؟'
];