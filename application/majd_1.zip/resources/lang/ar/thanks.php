<?php

return [


    'registration_title' => 'شكراً لك على التسجيل',
    'registration_subtitle' => 'مرحباً بك معنا',
    'registration_text' => 'أهلا بك عزيزي يمكنك الأن الذهاب إلى صفحة تسجيل الدخول والبدء بإستخدام حسابك..شكراً',
    'back_to_home' => 'عودة للصفحة الرئيسية',
    'go_to_login' => 'القيام بتسجيل الدخول',

];
