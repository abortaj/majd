<div class="container clearfix">

    {{--<div class="bg-light pt-80 pb-50">--}}

    {{--<div class="container">--}}

    {{--<div class="row">--}}

    {{--<div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">--}}

    {{--<div class="section-title">--}}

    {{--<h2>Find jobs by category</h2>--}}

    {{--</div>--}}

    {{--</div>--}}

    {{--</div>--}}

    {{--<div class="category-group-wrapper">--}}

    {{--<div class="GridLex-gap-30 no-mb">--}}

    {{--<div class="GridLex-grid-noGutter-equalHeight">--}}

    {{--<div class="GridLex-col-4_sm-6_xs-12_xss-12">--}}

    {{--<div class="category-group">--}}

    {{--<div class="icon">--}}
    {{--<i class="flaticon-streamline-outline-computer"></i>--}}
    {{--</div>--}}

    {{--<h5>Computer &amp; IT</h5>--}}
    {{--<p>Or kind rest bred with am shed then.</p>--}}
    {{--<p class="sub-category">--}}
    {{--<a href="#">Andriod</a>--}}
    {{--<a href="#">Web</a>--}}
    {{--<a href="#">Networking</a>--}}
    {{--<a href="#">Programming</a>--}}
    {{--<a href="#">More</a>--}}
    {{--</p>--}}

    {{--</div>--}}

    {{--</div>--}}

    {{--<div class="GridLex-col-4_sm-6_xs-12_xss-12">--}}

    {{--<div class="category-group">--}}

    {{--<div class="icon">--}}
    {{--<i class="flaticon-streamline-outline-crop"></i>--}}
    {{--</div>--}}

    {{--<h5>Engineering</h5>--}}
    {{--<p>In raptures building an bringing be.</p>--}}
    {{--<p class="sub-category">--}}
    {{--<a href="#">Process Engineer</a>--}}
    {{--<a href="#">Quality Engineer</a>--}}
    {{--<a href="#">Design Engineer</a>--}}
    {{--<a href="#">Civil Engineer</a>--}}
    {{--<a href="#">More</a>--}}
    {{--</p>--}}

    {{--</div>--}}

    {{--</div>--}}

    {{--<div class="GridLex-col-4_sm-6_xs-12_xss-12">--}}

    {{--<div class="category-group">--}}

    {{--<div class="icon">--}}
    {{--<i class="flaticon-streamline-outline-heart"></i>--}}
    {{--</div>--}}

    {{--<h5>Customer Service</h5>--}}
    {{--<p>Elderly is detract tedious assured private.</p>--}}
    {{--<p class="sub-category">--}}
    {{--<a href="#">Secretary</a>--}}
    {{--<a href="#">Stocker</a>--}}
    {{--<a href="#">Personal Banker</a>--}}
    {{--<a href="#">Deli Associate</a>--}}
    {{--<a href="#">More</a>--}}
    {{--</p>--}}

    {{--</div>--}}

    {{--</div>--}}

    {{--<div class="GridLex-col-4_sm-6_xs-12_xss-12">--}}

    {{--<div class="category-group">--}}

    {{--<div class="icon">--}}
    {{--<i class="flaticon-streamline-outline-remote-control-and-screen"></i>--}}
    {{--</div>--}}

    {{--<h5>Marketing</h5>--}}
    {{--<p>Travelling companions contrasted it.</p>--}}
    {{--<p class="sub-category">--}}
    {{--<a href="#">Account Manager</a>--}}
    {{--<a href="#">Merchandiser</a>--}}
    {{--<a href="#">Product Manager</a>--}}
    {{--<a href="#">Online Marketing</a>--}}
    {{--<a href="#">More</a>--}}
    {{--</p>--}}

    {{--</div>--}}

    {{--</div>--}}

    {{--<div class="GridLex-col-4_sm-6_xs-12_xss-12">--}}

    {{--<div class="category-group">--}}

    {{--<div class="icon">--}}
    {{--<i class="flaticon-streamline-outline-settings"></i>--}}
    {{--</div>--}}

    {{--<h5>Operations</h5>--}}
    {{--<p>Mistress strongly remember up to.</p>--}}
    {{--<p class="sub-category">--}}
    {{--<a href="#">Administrator</a>--}}
    {{--<a href="#">Building Operator</a>--}}
    {{--<a href="#">Senior Supervisor</a>--}}
    {{--<a href="#">Director Manager</a>--}}
    {{--<a href="#">More</a>--}}
    {{--</p>--}}

    {{--</div>--}}

    {{--</div>--}}

    {{--<div class="GridLex-col-4_sm-6_xs-12_xss-12">--}}

    {{--<div class="category-group">--}}

    {{--<div class="icon">--}}
    {{--<i class="flaticon-streamline-outline-shield-with-cross"></i>--}}
    {{--</div>--}}

    {{--<h5>Insurance</h5>--}}
    {{--<p>Ham him compass you proceed calling detract.</p>--}}
    {{--<p class="sub-category">--}}
    {{--<a href="#">Actuarial Analyst</a>--}}
    {{--<a href="#">Appraiser</a>--}}
    {{--<a href="#">Claims Examiner</a>--}}
    {{--<a href="#">Insurance Advisor</a>--}}
    {{--<a href="#">More</a>--}}
    {{--</p>--}}

    {{--</div>--}}

    {{--</div>--}}

    {{--</div>--}}

    {{--</div>--}}

    {{--</div>--}}

    {{--<div class="clear"></div>--}}

    {{--<div class="text-center mb-30">--}}
    {{--<a href="#" class="btn btn-lg btn-primary">Browse All Categories</a>--}}
    {{--</div>--}}

    {{--</div>--}}

    {{--</div>--}}
    {{--<div class="heading-block center nobottomborder bottommargin-lg">--}}
        {{--<h1>Discover Jobs By Categories</h1>--}}
        {{--<span>Specializes in creating Brand Identity for emerging Startups</span>--}}
    {{--</div>--}}

    {{--<div class="col_one_third">--}}
        {{--<div class="feature-box fbox-center fbox-outline fbox-effect nobottomborder">--}}
            {{--<div class="fbox-icon">--}}
                {{--<a href="#"><i class="icon-laptop i-alt"></i></a>--}}
            {{--</div>--}}
            {{--<h3>Programming & Tech</h3>--}}
            {{--<p class="tagcloud">--}}
                {{--<a href="#">Web Dev</a>--}}
                {{--<a href="#">Mobile Dev</a>--}}
                {{--<a href="#">Desktop Dev</a>--}}
                {{--<a href="#">Wordpress</a>--}}
                {{--<a href="#">More</a>--}}
            {{--</p>--}}
        {{--</div>--}}
    {{--</div>--}}

    {{--<div class="col_one_third">--}}
        {{--<div class="feature-box fbox-center fbox-outline fbox-effect nobottomborder">--}}
            {{--<div class="fbox-icon">--}}
                {{--<a href="#"><i class="icon-diamond i-alt"></i></a>--}}
            {{--</div>--}}
            {{--<h3>Design & Creative</h3>--}}
            {{--<p class="tagcloud">--}}
                {{--<a href="#">Logo</a>--}}
                {{--<a href="#">Web</a>--}}
                {{--<a href="#">Networking</a>--}}
                {{--<a href="#">Programming</a>--}}
                {{--<a href="#">More</a>--}}
            {{--</p>--}}
        {{--</div>--}}
    {{--</div>--}}

    {{--<div class="col_one_third col_last">--}}
        {{--<div class="feature-box fbox-center fbox-outline fbox-effect nobottomborder">--}}
            {{--<div class="fbox-icon">--}}
                {{--<a href="#"><i class="icon-edit i-alt"></i></a>--}}
            {{--</div>--}}
            {{--<h3>Writing</h3>--}}
            {{--<p class="tagcloud">--}}
                {{--<a href="#">Logo</a>--}}
                {{--<a href="#">Web</a>--}}
                {{--<a href="#">Networking</a>--}}
                {{--<a href="#">Programming</a>--}}
                {{--<a href="#">More</a>--}}
            {{--</p>--}}
        {{--</div>--}}
    {{--</div>--}}
    {{--<div class="clear"></div>--}}

    {{--<div class="col_one_third nobottommargin">--}}
        {{--<div class="feature-box fbox-center fbox-outline fbox-effect nobottomborder">--}}

            {{--<div class="fbox-icon">--}}
                {{--<a href="#"><i class="icon-briefcase i-alt"></i></a>--}}
            {{--</div>--}}
            {{--<h3>Accounting & Consulting</h3>--}}
            {{--<p class="tagcloud">--}}
                {{--<a href="#">Logo</a>--}}
                {{--<a href="#">Web</a>--}}
                {{--<a href="#">Networking</a>--}}
                {{--<a href="#">Programming</a>--}}
                {{--<a href="#">More</a>--}}
            {{--</p>--}}
        {{--</div>--}}
    {{--</div>--}}

    {{--<div class="col_one_third nobottommargin">--}}
        {{--<div class="feature-box fbox-center fbox-outline fbox-effect nobottomborder">--}}
            {{--<div class="fbox-icon">--}}
                {{--<a href="#"><i class="icon-user i-alt"></i></a>--}}
            {{--</div>--}}
            {{--<h3>Admin Support</h3>--}}
            {{--<p class="tagcloud">--}}
                {{--<a href="#">Logo</a>--}}
                {{--<a href="#">Web</a>--}}
                {{--<a href="#">Networking</a>--}}
                {{--<a href="#">Programming</a>--}}
                {{--<a href="#">More</a>--}}
            {{--</p>--}}
        {{--</div>--}}
    {{--</div>--}}

    {{--<div class="col_one_third nobottommargin col_last">--}}
        {{--<div class="feature-box fbox-center fbox-outline fbox-effect nobottomborder">--}}
            {{--<div class="fbox-icon">--}}
                {{--<a href="#"><i class="icon-puzzle i-alt"></i></a>--}}
            {{--</div>--}}
            {{--<h3>Sales & Marketing</h3>--}}
            {{--<p class="tagcloud">--}}
                {{--<a href="#">Logo</a>--}}
                {{--<a href="#">Web</a>--}}
                {{--<a href="#">Networking</a>--}}
                {{--<a href="#">Programming</a>--}}
                {{--<a href="#">More</a>--}}
            {{--</p>--}}
        {{--</div>--}}

    {{--</div>--}}


    {{--<div class="clearfix">--}}

    {{--</div>--}}

    {{--<div class="text-center" style="margin-top: 35px">--}}
        {{--<a href="" class="button button-border button-rounded button-fill fill-from-right button-blue">--}}
            {{--<span>All Categories</span>--}}
        {{--</a>--}}
    {{--</div>--}}
    {{--<div class="divider">--}}
        {{--<div class="icon-circle">--}}

        {{--</div>--}}
    {{--</div>--}}

</div>