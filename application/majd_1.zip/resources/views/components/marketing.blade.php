<div class="section notopborder nobottomborder nomargin nopadding nobg footer-stick">
    <div class="container clearfix">

        <div class="col_half nobottommargin topmargin">
            <img src="{{asset('site/images/services/4.jpg')}}" alt="Image" class="nobottommargin">
        </div>

        <div class="col_half subscribe-widget nobottommargin col_last">

            <div class="heading-block topmargin-lg">
                <h3><strong>GET 20% OFF*</strong></h3>
                <span>Our App scales beautifully to different Devices.</span>
            </div>

            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eveniet cumque, perferendis accusamus porro illo exercitationem molestias.</p>

            <div class="widget-subscribe-form-result"></div>
            <form id="widget-subscribe-form3" action="include/subscribe.php" role="form" method="post" class="nobottommargin">
                <div class="input-group" style="max-width:400px;">
                    <span class="input-group-addon"><i class="icon-email2"></i></span>
                    <input type="email" name="widget-subscribe-form-email" class="form-control required email" placeholder="Enter your Email">
                    <span class="input-group-btn">
										<button class="btn btn-danger" type="submit">Subscribe Now</button>
									</span>
                </div>
            </form>

        </div>

    </div>
</div>