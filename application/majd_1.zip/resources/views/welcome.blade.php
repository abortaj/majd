@extends('layouts.master')
@section('content')
    @include('components.sliders')
    <section id="content">

        <div class="content-wrap">


            @include('components.categories')
            @include('components.marketing')





        </div>

    </section>
    @stop