{{--<li>--}}
{{--    <a href="{{ route('profile',['id',$id]) }}">Dashboard</a>--}}
{{--</li>--}}
{{--<li>--}}
    {{--<a href="{{ route('profile') }}">Profile</a>--}}
{{--</li>--}}
{{--<li>--}}
    {{--<a href="{{ route('profile') }}">My Projects</a>--}}
{{--</li>--}}
{{--<li>--}}
    {{--<a href="{{ route('profile') }}">Payments</a>--}}
{{--</li>--}}
{{--<li>--}}
    {{--<a href="{{ route('profile') }}">Invite & Earn</a>--}}
{{--</li>--}}
{{--<li>--}}
    {{--<a href="{{ route('user-setting') }}">Setting</a>--}}
{{--</li>--}}
{{--<li>--}}
    {{--<a href="{{ route('logout') }}">Logout</a>--}}
{{--</li>--}}