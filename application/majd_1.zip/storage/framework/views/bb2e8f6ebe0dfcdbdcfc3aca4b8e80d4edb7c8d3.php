<?php $__env->startSection('content'); ?>
    <section id="content">

        <div class="content-wrap">

            <div class="container clearfix">

                <div class="clear"></div>

                <div class="col_two_fifth">
                    <?php echo $__env->make('user.components.user-left-side-info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>

                <div class="col_three_fifth col_last">
                    <?php echo $__env->make('user.components.user-right-side-info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>

                <div class="clear"></div>

            </div>

        </div>

    </section><!-- #content end -->


    
    
    
    
    

    
    
    
    
    
    

    
    
    
    
    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>