<?php $__env->startComponent('mail::message'); ?>
# Welcom To Test App

Tanks For Sing Up, **We Really appreciate ** it. Let _Know if we can_ do more to please you!,
<?php $__env->startComponent('mail::button', ['url' => 'http://localhost/majd_1/public']); ?>
View My Dashboard
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
