<div class="pricing-box best-price">
    <div class="pricing-price">
        <img src="storage/users/avatar.jpg" class="aligncenter img-circle img-thumbnail notopmargin nobottommargin" alt="Avatar" style="max-width: 100px;">
    </div>

    <div class="pricing-title">
        <h3>Mowaffaq Ali Rabeh</h3>
        <span>Web Developer</span>
        <i class="icon-star"></i>
        <i class="icon-star"></i>
        <i class="icon-star"></i>
        <i class="icon-star"></i>
        <i class="icon-star"></i>
        5.0 ( 23 reviews )
    </div>
    <div class="pricing-action">
        <a href="#" class="btn btn-danger  btn-sm bgcolor border-color">Contact Me</a>
        <a href="#" class="btn btn-danger  btn-sm bgcolor border-color">Hire Me</a>
    </div>
    <div class="container text-left">
        Donec sed odio dui. Nulla vitae elit libero, a pharetra augue. Nullam id dolor id nibh ultricies vehicula ut id elit.
        <a href="">more...</a>
        <div class="pricing-features">
            <ul>
                <li><i class="icon-location"></i><strong> Saudi Arabia 3:00pm</strong></li>
                <li><i class="icon-"></i><strong>Member since </strong>August 27, 2015</li>
                <li><i class="icon-money"></i><strong> $10 /hr</strong></li>
            </ul>
        </div>
    </div>
    <div class="fancy-title title-center" style="padding-top: 10px; margin-bottom: 15px">
        <h4>Skills</h4>
    </div>
    <div class="tagcloud bottommargin container clearfix">
        <a href="">PHP</a>
        <a href="">HTML/CSS</a>
        <a href="">JAVASCRIPT</a>
        <a href="">C#</a>
        <a href="">VB.NET</a>
        <a href="">VB.NET</a>
        <a href="">VB.NET</a>
        <a href="">VB.NET</a>
        <a href="">VB.NET</a>
    </div>




</div>