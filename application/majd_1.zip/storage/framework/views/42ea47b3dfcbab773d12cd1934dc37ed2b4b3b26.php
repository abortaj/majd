<?php $__env->startSection('content'); ?>

    <div class="content-wrap">

        <div class="container clearfix">

            <div class="row clearfix">

                <div class="col-sm-10 col-md-offset-1">
                    <a href="javascript:void(0)" class="edit-action1 edit-profile-image">
                        
                        <i class="fa fa-pencil  user-image-icon" style="position: absolute;top: 10px;right: 10px;cursor: pointer;"></i>
                    </a>
                    <div class="heading-block noborder">

                        <span><?php echo app('translator')->getFromJson('profile.your_profile_bio'); ?></span>
                    </div>

                    <div class="clear"></div>

                        <div class="tabs tabs-alt clearfix" id="tabs-profile">

                            <ul class="tab-nav clearfix">
                                <li><a href="#tab-info"><i class="icon-info"></i> <?php echo app('translator')->getFromJson('profile.tab_info'); ?></a></li>
                                <li><a href="#tab-email"><i class="icon-email"></i> <?php echo app('translator')->getFromJson('profile.tab_email'); ?></a></li>
                                <li><a href="#tab-password"><i class="icon-lock"></i> <?php echo app('translator')->getFromJson('profile.tab_password'); ?></a></li>
                            </ul>

                            <div class="tab-container">

                                <div class="tab-content clearfix" id="tab-info">
                                    <?php echo $__env->make('user.profile.profile-form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </div>

                                <div class="tab-content clearfix" id="tab-email">
                                    
                                </div>

                                <div class="tab-content clearfix" id="tab-password">
                                    
                                </div>

                            </div>

                        </div>

                    </div>


                <div class="line visible-xs-block"></div>

            </div>

        </div>

    </div>


                                
                                
                                
                                
                                
                                

<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<style>
    .user-image-icon{
        visibility: hidden;
    }
    .user-image:hover + .user-image-icon,.user-image-icon:hover {
        visibility:visible !important;
    }
</style>
<script>PROFILE={
        EDIT_PROFILE_IMAGE:"<?php echo app('translator')->getFromJson("profile.edit_my_image"); ?>",
        UPDATE:"<?php echo e(route('profile.update.image')); ?>",
    }</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>