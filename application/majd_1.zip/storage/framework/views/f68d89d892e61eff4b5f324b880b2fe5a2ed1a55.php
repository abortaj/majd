Thank you for registration
to verify your email click
<a href="<?php echo e(route('email.verify',['email'=>$user->email,'verify_token'=>$user->verify_token])); ?>">here</a>