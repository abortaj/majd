<!-- Top Bar
		============================================= -->
<div id="top-bar">

    <div class="container clearfix">

        <div class="col_full  nobottommargin" style="margin-bottom:0px !important">

            <!-- Top Links
            ============================================= -->
            <div class="top-links">
                <ul>
                    <?php if(auth()->guard()->check()): ?>
                        <li>
                            <a href="#" style="color:black">
                                <img src="<?php echo e(auth()->user()->image); ?>" class="user-image img-circle img-thumbnail nomargin" alt="Avatar" style="max-width: 35px;">
                            </a>
                            <ul style="display: none;">
                                <li>
                                    <a href="<?php echo e(route('profile')); ?>"><?php echo app('translator')->getFromJson('header.profile'); ?></a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('logout')); ?>"><?php echo app('translator')->getFromJson('header.logout'); ?></a>
                                </li>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-panel')): ?>
                        <li>
                            <a href="<?php echo e(route('admin').'#/home'); ?>">
                                <?php echo app('translator')->getFromJson('header.admin'); ?>
                            </a>
                        </li>
                    <?php endif; ?>
                    @author
                        <li>
                            <a href="<?php echo e(route('author')); ?>">
                                <?php echo app('translator')->getFromJson('header.author'); ?>
                            </a>
                        </li>
                        <li><a href="<?php echo e(route('post.create')); ?>"><?php echo app('translator')->getFromJson('header.new_post'); ?></a></li>
                    @endauthor
                    <?php if(auth()->guard()->guest()): ?>
                        <li><a href="<?php echo e(route('login')); ?>"><?php echo app('translator')->getFromJson('header.login'); ?></a></li>
                        <li><a href="<?php echo e(route('register')); ?>"><?php echo app('translator')->getFromJson('header.register'); ?></a></li>
                    <?php endif; ?>
                </ul>

            </div>
        </div>

    </div>

</div><!-- #top-bar end -->

<!-- Header
============================================= -->
<header id="header">

    <div id="header-wrap">

        <div class="container clearfix">

            <div id="primary-menu-trigger"><i class="icon-reorder"></i></div>

            <!-- Logo
            ============================================= -->
            <div id="logo">
                <a href="<?php echo e(route('home')); ?>" class="standard-logo">
                    <img src="<?php echo e(asset('site/images/logo.png')); ?>">
                </a>
                <a href="<?php echo e(route('home')); ?>" class="retina-logo">
                    <img src="<?php echo e(asset('site/images/logo@2x.png')); ?>">
                </a>
            </div><!-- #logo end -->

            <!-- Primary Navigation
            ============================================= -->
            

        </div>

    </div>

</header><!-- #header end -->