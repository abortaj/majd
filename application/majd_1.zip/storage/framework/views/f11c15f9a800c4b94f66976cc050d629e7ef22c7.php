<?php $__env->startSection('content'); ?>
    <section id="content">

        <div class="content-wrap nopadding">

            <div class="section nopadding nomargin" style="width: 100%; height: 100%; position: absolute; left: 0; top: 0; background: #444;"></div>

            <div class="section nobg full-screen nopadding nomargin">
                <div class="container-fluid vertical-middle divcenter clearfix">

                    <div class="center">
                        <a href="index.html"><img src="<?php echo e(asset('site/images/logo-dark.png')); ?>" alt="Canvas Logo"></a>
                    </div>

                    <div class="card divcenter noradius noborder" style="max-width: 800px;">
                        <div class="card-body" style="padding: 40px;">
                             <?php echo Form::open(['route'=>'register', 'class'=>'auto-form nobottommargin']); ?>

                            

                                <div class="col_half">
                                    <label for="register-form-first-name"><?php echo app('translator')->getFromJson('register.first_name'); ?></label>
                                    <input type="text"  name="first_name" value="<?php echo e(old('first_name')); ?>" class="form-control" />
                                </div>
                                <div class="col_half col_last">
                                    <label for="register-form-last-name"><?php echo app('translator')->getFromJson('register.last_name'); ?></label>
                                    <input type="text"  name="last_name" value="<?php echo e(old('last_name')); ?>" class="form-control" />
                                </div>
                                <div class="clear"></div>
                                <div class="col_full">
                                    <label for="register-form-email"><?php echo app('translator')->getFromJson('register.email'); ?></label>
                                    <input type="text" name="email" value="<?php echo e(old('email')); ?>" class="form-control" />
                                </div>

                                <div class="clear"></div>

                                <div class="col_half">
                                    <label for="register-form-password"><?php echo app('translator')->getFromJson('register.password'); ?></label>
                                    <input type="password"  name="password" class="form-control" />
                                </div>

                                <div class="col_half col_last">
                                    <label for="register-form-repassword"><?php echo app('translator')->getFromJson('register.reenter_password'); ?></label>
                                    <input type="password" name="password_confirmation"  class="form-control" />
                                </div>
                                <div class="clear"></div>
                                <div class="col_half">
                                    <label for="register-form-location">Location</label>
                                    <input type="text" name="location" value="Riyadh" disabled  class="form-control" style="background-color: #ffffff" />
                                </div>

                                <div class="clear"></div>

                                <div class="col_full nobottommargin">
                                    <button class="button button-3d button-black nomargin" id="register-form-submit" name="register-form-submit" type="submit"><?php echo app('translator')->getFromJson('register.register'); ?></button>
                                </div>
                            <?php echo e(Form::close()); ?>

                            

                            <div class="line line-sm"></div>
                            <div>
                                <h4 style="margin-bottom: 15px;"><?php echo app('translator')->getFromJson('register.alternative_register'); ?></h4>
                                <a href="#" class="social-icon si-colored si-gplus" title="Google Plus">
                                    <i class="icon-gplus"></i>
                                    <i class="icon-gplus"></i>
                                </a>
                                <a href="#" class="social-icon si-colored si-facebook" title="Facebook">
                                    <i class="icon-facebook"></i>
                                    <i class="icon-facebook"></i>
                                </a>
                                <a href="#" class="social-icon si-colored si-linkedin" title="Linked In">
                                    <i class="icon-linkedin"></i>
                                    <i class="icon-linkedin"></i>
                                </a>
                            </div>

                            <div class="line line-sm"></div>
                            <div class="col_full nobottommargin text-center">
                                <a href="<?php echo e(route('login')); ?>"><?php echo app('translator')->getFromJson('register.you_have_account'); ?></a>
                            </div>
                        </div>
                    </div>

                    <div class="center dark"><small>Copyrights &copy; All Rights Reserved by Canvas Inc.</small></div>

                </div>
            </div>

        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>