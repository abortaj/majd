<div class="heading-block noborder">
    <span><?php echo app('translator')->getFromJson('profile.info_hint'); ?></span>
</div>
<?php echo e(Form::open(['route'=>'profile.update', 'class'=>'auto-form'])); ?>

    <div class="col_full">
        <label>First Name:</label>
        <?php echo e(Form::text('first_name',auth()->user()->first_name,['class'=>'sm-form-control'])); ?>

    </div>

    <div class="col_full">
        <label>Last Name:</label>
        <?php echo e(Form::text('last_name',auth()->user()->last_name,['class'=>'sm-form-control'])); ?>

    </div>
    <div class="col_full">
        <label>Email:</label>
        <?php echo e(Form::text('email',auth()->user()->email,['class'=>'sm-form-control'])); ?>

    </div>
    <div class="col_full">
        <label><?php echo app('translator')->getFromJson('profile.bio'); ?></label>
        <?php echo e(Form::textarea('bio',auth()->user()->bio,['class'=>'sm-form-control'])); ?>

    </div>
    <div class="col_full">
        <button class="button" type="submit"><?php echo app('translator')->getFromJson('profile.update_profile_btn'); ?></button>
    </div>
<?php echo e(Form::close()); ?>