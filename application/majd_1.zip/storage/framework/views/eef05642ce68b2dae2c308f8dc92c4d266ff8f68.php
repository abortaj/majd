<?php $__env->startSection('content'); ?>

    <div class="heading-block center">
        <h1><?php echo app('translator')->getFromJson('thanks.registration_title'); ?></h1>
        <span><?php echo app('translator')->getFromJson('thanks.registration_subtitle'); ?></span>
    </div>

    <div class="style-msg successmsg">
        <div class="sb-msg"><i class="icon-thumbs-up"></i> <?php echo app('translator')->getFromJson('thanks.registration_text'); ?></div>
    </div>

    <a href="<?php echo e(route('home')); ?>" class="button button-xlarge tright">
        <?php echo app('translator')->getFromJson('thanks.back_to_home'); ?> <i class="icon-home"></i>
    </a>


    <a href="<?php echo e(route('login')); ?>" class="button button-xlarge tright">
        <?php echo app('translator')->getFromJson('thanks.go_to_login'); ?> <i class="icon-lock"></i>
    </a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.thanks', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>